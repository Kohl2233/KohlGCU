﻿namespace MusicAppSQL
{
    internal class Track
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Number { get; set; }
        public string VideoURL { get; set; }
        public string Lyrics {  get; set; }
    }
}