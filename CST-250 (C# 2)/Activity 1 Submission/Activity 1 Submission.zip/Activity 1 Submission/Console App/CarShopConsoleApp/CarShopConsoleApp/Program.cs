﻿using CarClassLibrary;
namespace CarShopConsoleApp
{
    internal class Program
    {
        static Store CarStore = new Store();
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
        }
    }
}