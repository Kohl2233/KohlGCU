﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GreedyAlgo
{
    public class TradeGood
    {
        // Attributes
        public int weight;
        public int value;

        // Constructor
        public TradeGood(int weight, int value)
        {
            this.weight = weight;
            this.value = value;
        }
    }
}
