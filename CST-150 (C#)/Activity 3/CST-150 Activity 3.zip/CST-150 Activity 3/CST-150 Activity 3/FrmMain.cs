/* Kohl Johnson
 * CST-150
 * Activity 3
 * 11-10-2023
 * Citation(s):
 */

using System.Windows.Forms.VisualStyles;

namespace CST_150_Activity_3
{
    public partial class FrmMain : Form
    {
        public FrmMain()
        {
            InitializeComponent();
            openFileDialog1.InitialDirectory = Application.StartupPath + @"Data";
            openFileDialog1.Title = "Browse Txt Files";
            openFileDialog1.DefaultExt = "txt";
            openFileDialog1.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";

            // Set all Labeles to Hidden upon program start
            lblResults.Visible = false;
            lblSelectedFile.Visible = false;
        }

        /// <summary>
        /// Click Event Handler For btnReadFile Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnReadFileClickEvent(object sender, EventArgs e)
        {
            // Variable Declarations/Initialization
            string txtFile = "";
            string dirLocation = "";
            const int padSpace = 20;
            string header1 = "Type", header2 = "Color", header3 = "Qty";
            string headerLine1 = "----", headerLine2 = "-----", headerLine3 = "---";

            // On Button Click, Prompt the Open File Dialog
            if (this.openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                txtFile = this.openFileDialog1.FileName; // Read in the text file selected
                dirLocation = Path.GetFullPath(openFileDialog1.FileName); // get the path of said file
                lblSelectedFile.Text = txtFile; // display selected file path
                lblSelectedFile.Visible = true; // set lbl to visible

                string[] lines = File.ReadAllLines(txtFile); // read all lines at once
                lblResults.Text = "";
                lblResults.Text = string.Format("{0}{1}{2}\n", header1.PadRight(padSpace), header2.PadRight(padSpace), header3.PadRight(padSpace));
                lblResults.Text += string.Format("{0}{1}{2}\n", headerLine1.PadRight(padSpace), headerLine2.PadRight(padSpace), headerLine3.PadRight(padSpace));
                foreach (string line in lines)
                {
                    string[] inventoryList = line.Split(", "); // split each line into array
                    for (int i = 0; i < inventoryList.Length; i++)
                    {
                        lblResults.Text += inventoryList[i].PadRight(padSpace);
                    }
                    lblResults.Text += "\n"; // need new line after each iteration
                }

                lblResults.Visible = true; // make lbl visible
            }
        }
    }
}