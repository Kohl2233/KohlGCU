/* Kohl Johnson
 * CST-150
 * Class Project
 * 11-11-2023
 * Citation(s): 
 *      String Format Help: https://learn.microsoft.com/en-us/dotnet/api/system.string.format?view=net-7.0#Starting 
 */


namespace Class_Project
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            openFileDialog1.InitialDirectory = Application.StartupPath + @"Data";
            openFileDialog1.Title = "Browse Txt Files";
            openFileDialog1.DefaultExt = "txt";
            openFileDialog1.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
            lblInventoryDisplay.Visible = false; // set label to hidden
        }

        /// <summary>
        /// Handles the Click Event for btnDisplayInventory
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DisplayInvBtnClickEvent(object sender, EventArgs e)
        {
            // Variable Declarations
            string inventoryFile = "";
            string dirLocation = "";
            string headerName = "Name", headerQty = "Qty", headerPrice = "Price";
            string headerLine = new string('-', 65);

            // Prompt the Open File Dialog
            if (this.openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                inventoryFile = this.openFileDialog1.FileName; // Read selected file
                dirLocation = Path.GetFullPath(openFileDialog1.FileName); // Get path of selected file

                // Inventory Reading
                string[] lines = File.ReadAllLines(inventoryFile); // read in all contents
                lblInventoryDisplay.Text = string.Format("{0,-50}{1,-3}{2, 12}\n",
                    headerName,
                    headerQty,
                    headerPrice);
                lblInventoryDisplay.Text += headerLine + "\n";
                foreach (string line in lines)
                {
                    string[] inventoryList = line.Split("@ "); // split each attribute up

                    // Assign Attributes
                    string name = inventoryList[0];
                    string descr = inventoryList[1];
                    int qty = Int32.Parse(inventoryList[2]);
                    float price = float.Parse(inventoryList[3]);
                    string releaseDate = inventoryList[4];
                    int runtime = Int32.Parse(inventoryList[5]);
                    string rating = inventoryList[6];
                    string review = inventoryList[7];

                    // Add Inventory Item to Display
                    lblInventoryDisplay.Text += string.Format("{0,-50}{1,-3:F1}{2,12:C2}", name, qty, price); // display details
                    lblInventoryDisplay.Text += "\n"; // add newline after each item is done
                }
                lblInventoryDisplay.Visible = true;
            }


            // Display Details
            //var header = String.Format("{0,-60}{1,3}{2,12}\n", "Name", "Qty", "Price ($)");
            //var item1Info = String.Format("{0,-60}{1,3:F1}{2,12:C2}\n", item1Name, item1Qty, item1Price);
            //var item2Info = String.Format("{0,-60}{1,3:F1}{2,12:C2}\n", item2Name, item2Qty, item2Price);

            //lblInvDisplayHeader.Text = header;
            //lblInventoryDisplay.Text = item1Info + item2Info;
            //lblInvDisplayHeader.Visible = true;
            //lblInventoryDisplay.Visible = true;
        }
    }
}