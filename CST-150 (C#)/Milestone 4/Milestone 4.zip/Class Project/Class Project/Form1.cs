/* Kohl Johnson
 * CST-150
 * Class Project
 * 11-18-2023
 * Citation(s): 
 *      String Format Help: https://learn.microsoft.com/en-us/dotnet/api/system.string.format?view=net-7.0#Starting 
 */


namespace Class_Project
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            openFileDialog1.InitialDirectory = Application.StartupPath + @"Data";
            openFileDialog1.Title = "Browse Txt Files";
            openFileDialog1.DefaultExt = "txt";
            openFileDialog1.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
            lblInventoryDisplay.Visible = false; // set label to hidden
        }


        /// <summary>
        /// Handles the Click Event for btnDisplayInventory ----- MAIN METHOD -----
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DisplayInvBtnClickEvent(object sender, EventArgs e)
        {
            // Prompt the Open File Dialog
            if (this.openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                DisplayInventory(); // display full inventory
            }
        }


        /// <summary>
        /// Function That Pulls Together All Functions to Fully Display the Inventory
        /// </summary>
        private void DisplayInventory()
        {
            // Variable Declarations
            string inventoryFile = "";
            string headerName = "Name", headerQty = "Qty", headerPrice = "Price";
            string headerLine = new string('-', 65);
            string headerString = string.Format("{0,-50}{1,-3}{2, 12}\n{3}",
                headerName,
                headerQty,
                headerPrice,
                headerLine);

            inventoryFile = getSelectedInventoryFile(); // get selected inventory file
            addTextToInventoryDisplay(headerString, true); // display the header
            string[] inventory = readInventoryFile(inventoryFile); // read inventory file
            processInventoryProducts(inventory); // process read inventory string and display
            lblInventoryDisplay.Visible = true; // show inventory display label
        }


        /// <summary>
        /// Function to Grab the Selected Inventory File
        /// </summary>
        /// <returns></returns>
        private string getSelectedInventoryFile()
        {
            return openFileDialog1.FileName;
        }


        /// <summary>
        /// Function to Read in Products From Inventory Text File
        /// </summary>
        /// <param name="file"></param>
        /// <returns></returns>
        private string[] readInventoryFile(string file)
        {
            string[] lines = File.ReadAllLines(file); // read in all contents from file
            return lines;
        }


        /// <summary>
        /// Function to Process Product String From Inventory Text File
        /// </summary>
        /// <param name="lines"></param>
        private void processInventoryProducts(string[] lines)
        {
            foreach (string line in lines)
            {
                string[] inventoryList = line.Split("@ "); // split each attribute up

                // Assign Attributes
                string name = inventoryList[0];
                string descr = inventoryList[1];
                int qty = Int32.Parse(inventoryList[2]);
                float price = float.Parse(inventoryList[3]);
                string releaseDate = inventoryList[4];
                int runtime = Int32.Parse(inventoryList[5]);
                string rating = inventoryList[6];
                string review = inventoryList[7];

                // Add Inventory Item to Display
                string productDisplay = string.Format("{0,-50}{1,-3:F1}{2,12:C2}", name, qty, price); // display details
                addTextToInventoryDisplay(productDisplay, false);
            }
        }


        /// <summary>
        /// Function to Add Text to the Inventory Display Label
        /// </summary>
        /// <param name="text"></param>
        /// <param name="clear"></param>
        private void addTextToInventoryDisplay(string text, bool clear)
        {
            if (clear) { lblInventoryDisplay.Text = ""; } // reset lblInventoryDisplay
            lblInventoryDisplay.Text += (text + "\n"); // add supplied text to label, with newline at end
        }
    }
}