package app;

public class Main {
	public static void main(String[] args) {
		Person person1 = new Person("Kohl", 23, "Student", 0, "Astronomy");
		person1.doHobby();
		person1.introduceSelf();
	}
}
